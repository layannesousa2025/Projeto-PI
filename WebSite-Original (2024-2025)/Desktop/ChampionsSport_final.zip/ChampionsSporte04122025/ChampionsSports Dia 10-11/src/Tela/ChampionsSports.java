/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Tela;

import com.jtattoo.plaf.mcwin.McWinLookAndFeel;
import com.jtattoo.plaf.smart.SmartLookAndFeel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Jose55869936
 */
public class ChampionsSports {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            // Define o Look and Feel para Quaqua
            UIManager.setLookAndFeel(new McWinLookAndFeel());
Login l =  new Login();

l.setVisible(true);
        
           
        } catch (UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
        
     
    }
    
}
