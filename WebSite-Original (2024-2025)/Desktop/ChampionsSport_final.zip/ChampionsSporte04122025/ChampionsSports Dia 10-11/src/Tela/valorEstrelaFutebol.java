/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tela;

/**
 *
 * @author Jose55869936
 */
class valorEstrelaFutebol {
    
}
