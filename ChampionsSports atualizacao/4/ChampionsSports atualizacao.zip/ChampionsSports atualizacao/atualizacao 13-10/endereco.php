<?php
session_start(); // Inicia a sessão para poder verificar o login

// Verifica se o usuário está logado. Se não, não deve estar nesta página.
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.html");
    exit;
}

// Verifica se os dados do formulário foram enviados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Dados de conexão com o banco de dados
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "banco_teste01";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Coleta os dados do formulário
    $cep = $_POST['cep'];
        $uf = $_POST['uf'];
        $rua = $_POST['rua'];
        $bairro = $_POST['bairro'];
        $cidade = $_POST['cidade'];
        $complemento = $_POST['complemento'];
    $id_usuario = $_SESSION['id']; // Pega o ID principal do usuário da sessão logada

    // Insere os dados do endereço na tabela
    $insert_sql = "INSERT INTO endereco (cep, uf, rua, bairro, cidade, complemento, id_usuarios) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("ssssssi", $cep, $uf, $rua, $bairro, $cidade, $complemento, $id_usuario);
    
    if ($insert_stmt->execute()) {
        header("Location: telaPrincipal.php");
        exit;
    } else {
        echo "Erro: " . $insert_stmt->error;
    }
    $insert_stmt->close();
    $conn->close();
    exit; // Importante: sai do script para não renderizar o HTML abaixo após o POST.
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela-endereco</title>
</head>
<style>
    /* ===== RESET ===== */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* ===== BASE ===== */
    body {
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background-color: #1a1a2e;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        padding: 20px;
    }

    /* ===== CARD ===== */
    .card {
        background: #fff;
        max-width: 700px;
        width: 100%;
        padding: 25px 30px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }

    .card h1 {
        font-size: 1.6rem;
        margin-bottom: 10px;
        color: #222;
    }

    .card .lead {
        font-size: 0.95rem;
        color: #555;
        margin-bottom: 20px;
    }

    /* ===== FORM ===== */
    .form-grid {
        display: grid;
        gap: 18px;
    }

    .form-grid .span-full {
        grid-column: 1 / -1;
    }

    .cep-uf {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 15px;
    }

    label {
        display: block;
        margin-bottom: 6px;
        font-size: 0.9rem;
        font-weight: 600;
        color: #333;
    }

    input,
    select,
    textarea {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #dcdfe6;
        border-radius: 8px;
        font-size: 0.95rem;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    input:focus,
    select:focus,
    textarea:focus {
        border-color: #4a90e2;
        box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
        outline: none;
    }

    .hint {
        font-size: 0.8rem;
        color: #777;
        margin-top: 4px;
    }

    /* ===== ACTIONS ===== */
    .actions {
        display: flex;
        justify-content: flex-end;
        gap: 12px;
        margin-top: 20px;
    }

    button {
        padding: 10px 20px;
        border-radius: 8px;
        font-size: 0.95rem;
        cursor: pointer;
        border: none;
        transition: all 0.2s ease;
    }

    button.primary {
        background: #4a90e2;
        color: #fff;
    }

    button.primary:hover {
        background: #357ABD;
    }

    button.ghost {
        background: #f1f1f1;
        color: #333;
    }

    button.ghost:hover {
        background: #e1e1e1;
    }

    /* ===== RESPONSIVIDADE ===== */
    @media (max-width: 600px) {
        .cep-uf {
            grid-template-columns: 1fr;
        }
    }

    /* Botão de voltar */
    .voltar {
        position: absolute;
        top: 10px;
        left: 10px;

    }

    .voltar img {
        background-color: white;
        border-radius: 50%;
        width: 40px;
        height: 40px;
    }
</style>

<body>
    <!-- Botão Voltar -->
    <div class="voltar">
        <a href="telaPrincipal.php">
            <img src="./img/button (2).png" alt="Botão voltar">
        </a>
    </div>

    <div class="card" role="region" aria-label="Formulário de endereço">
        <h1>Endereço</h1>
        <p class="lead">Preencha os dados do endereço. Campos com * são obrigatórios.</p>

        <form id="enderecoForm" novalidate action="endereco.php" method="POST">
            <div class="form-grid">

                <!-- CEP / UF / Situação -->
                <div class="span-full cep-uf">
                    <div class="cep col">
                        <label for="cep">CEP *</label>
                        <input id="cep" name="cep" type="text" placeholder="00000-000" maxlength="9"
                            pattern="\d{5}-?\d{3}" required>
                        <div class="hint">Formato: 00000-000</div>
                    </div>

                    <div class="uf col very-small">
                        <label for="uf">UF *</label>
                        <select id="uf" name="uf" required>
                            <option value="">Selecione</option>
                            <option>AC</option>
                            <option>AL</option>
                            <option>AP</option>
                            <option>AM</option>
                            <option>BA</option>
                            <option>CE</option>
                            <option>DF</option>
                            <option>ES</option>
                            <option>GO</option>
                            <option>MA</option>
                            <option>MT</option>
                            <option>MS</option>
                            <option>MG</option>
                            <option>PA</option>
                            <option>PB</option>
                            <option>PR</option>
                            <option>PE</option>
                            <option>PI</option>
                            <option>RJ</option>
                            <option>RN</option>
                            <option>RS</option>
                            <option>RO</option>
                            <option>RR</option>
                            <option>SC</option>
                            <option>SP</option>
                            <option>SE</option>
                            <option>TO</option>
                        </select>
                    </div>
                </div>


                    <!-- Rua -->
                    <div>
                        <label for="rua">Rua *</label>
                        <input id="rua" name="rua" type="text" placeholder="Nome da rua, avenida, etc" required>
                    </div>

                    <!-- Bairro -->
                    <div>
                        <label for="bairro">Bairro *</label>
                        <input id="bairro" name="bairro" type="text" placeholder="Ex: Centro" required>
                    </div>

                    <!-- Cidade -->
                    <div>
                        <label for="cidade">Cidade *</label>
                        <input id="cidade" name="cidade" type="text" placeholder="Ex: São Paulo" required>
                    </div>

                    <!-- Complemento -->
                    <div>
                        <label for="complemento">Complemento</label>
                        <input id="complemento" name="complemento" type="text" placeholder="Apto, bloco, referência">
                    </div>

                    <!-- Observações -->
                    <div class="span-full">
                        <label for="observacoes">Observações</label>
                        <textarea id="observacoes" name="observacoes" rows="3"
                            placeholder="Algo que queira acrescentar..."
                            style="resize:vertical;padding:10px 12px;border-radius:8px;border:1px solid #e6e9ef;"></textarea>
                    </div>


                <div class="actions">
                    <button type="reset" class="ghost">Limpar</button>
                    <button type="submit" class="primary">Salvar</button>
                </div>
            </div>
        </form>
    </div>


</body>

</html>