/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */

package Tela;

import Conexao.ConexaoMysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import javax.swing.text.MaskFormatter;





public class TelaCadastro2 extends javax.swing.JDialog {

    // String deficienteVisual,
   // deficienteIntelectual,
   // deficienteAudio,
    //deficienteNeuro,
    //deficienteMotora,
    //deficientePsicologica,
    //deficienteCardiaco,
   // outros;
    public TelaCadastro2(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        setLocation(400, 50);
        initComponents();
       
        
        try {
        //mascara cpf
            javax.swing.text.MaskFormatter cpfMask = new javax.swing.text.MaskFormatter("###.###.###-##");
        cpfMask.setPlaceholderCharacter('_');
        cpfMask.install(cpf); // <-- aplica a máscara no campo CPF
        //mascara telefone
         MaskFormatter mascaraTelefone = new MaskFormatter("(##)#####-####");
    mascaraTelefone.setPlaceholderCharacter('_');
    mascaraTelefone.install(telefone);
    } catch (Exception e) {
        e.printStackTrace();
    }
        
        

        
        
        atualizarValores();
        acessibilidade();
        
        
        
        
         codigo.setEnabled(false);  
      salvar_cadastro.setEnabled(false);
       editar_cadastro.setEnabled(false);
       excluir_cadastro.setEnabled(false);
              
        
    }
    
    public void Limparcampo(){
       nome.setText(null);
        cpf.setText(null);
         telefone.setText(null);
         email.setText(null);
         senha.setText(null);
         confirmar_senha.setText(null);
         possuiDeficiencia.clearSelection();
         deficiencias.clearSelection();
         
         
        
    }

   public void acessibilidade(){
       rbvisual.setVisible(false);
       rbauditivo.setVisible(false);
       rbmotora.setVisible(false);
       rboutros.setVisible(false);
       rbcardiaca.setVisible(false);
       rbintelectual.setVisible(false);
       rbneurologica.setVisible(false);
       rbpisiquica.setVisible(false);
    
}

   public void atualizarValores(){
      DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
    modelo.setNumRows(0);

    String sql =
        "SELECT u.id_cadastro_usuario, u.nome, l.usuario AS usuario_login, u.cpf, u.data_nascimento, "
      + "u.telefone, u.email, "
      + "CONCAT(IF(a.d_visual=1,'Visual ', ''), "
      + "IF(a.d_auditiva=1,'Auditiva ', ''), "
      + "IF(a.d_motora=1,'Motora ', ''), "
      + "IF(a.d_cardiaca=1,'Cardíaca ', ''), "
      + "IF(a.d_intelectual=1,'Intelectual ', ''), "
      + "IF(a.d_neurologica=1,'Neurológica ', ''), "
      + "IF(a.d_psiquica=1,'Psíquica ', ''), "
      + "IF(a.outros=1,'Outros ', '')) AS deficiencia, "
      + "u.situacao, "
      + "l.tipo_usuario "
      + "FROM cadastro_usuario u "
      + "INNER JOIN login l ON l.id_login = u.id_login "
      + "LEFT JOIN acessibilidade a ON a.id_cadastro_usuario = u.id_cadastro_usuario";


    try {
        Connection conn = ConexaoMysql.conexaoBanco();
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        while(rs.next()){
            Object[] dados = {
                rs.getInt("id_cadastro_usuario"),
                rs.getString("nome"),
                rs.getString("tipo_usuario") ,
                rs.getString("cpf"),
                rs.getString("data_nascimento"),
                rs.getString("telefone"),
                rs.getString("email"),
                rs.getString("deficiencia"),
                rs.getString("situacao"),
                    
            };
            modelo.addRow(dados);
        }

        rs.close();
        stmt.close();
        conn.close();
        
    } catch (SQLException ex) {
        Logger.getLogger(TelaCadastro2.class.getName()).log(Level.SEVERE, null, ex);
    }



   }
    
   
     private void pesquisarCadastro() {

   String texto = pesquisaNome.getText().trim();
    String param = "%" + texto + "%";

    String sql =
        "SELECT u.id_cadastro_usuario, u.nome, l.usuario AS usuario_login, u.cpf, u.data_nascimento, "
      + "u.telefone, u.email, "
      + "CONCAT( "
      + "  IF(a.d_visual=1,'Visual ', ''), "
      + "  IF(a.d_auditiva=1,'Auditiva ', ''), "
      + "  IF(a.d_motora=1,'Motora ', ''), "
      + "  IF(a.d_cardiaca=1,'Cardíaca ', ''), "
      + "  IF(a.d_intelectual=1,'Intelectual ', ''), "
      + "  IF(a.d_neurologica=1,'Neurológica ', ''), "
      + "  IF(a.d_psiquica=1,'Psíquica ', ''), "
      + "  IF(a.outros=1,'Outros ', '') "
      + ") AS deficiencia, "
      + "u.situacao, "
      + "l.tipo_usuario "
      + "FROM cadastro_usuario u "
      + "INNER JOIN login l ON l.id_login = u.id_login "
      + "LEFT JOIN acessibilidade a ON a.id_cadastro_usuario = u.id_cadastro_usuario "
      + "WHERE u.nome LIKE ? "
      + "OR u.cpf LIKE ? "
      + "OR u.telefone LIKE ? "
      + "OR u.email LIKE ? "
      + "OR l.usuario LIKE ? "
      + "OR l.tipo_usuario LIKE ?";

    try (Connection con = ConexaoMysql.conexaoBanco();
         PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, param);
        pst.setString(2, param);
        pst.setString(3, param);
        pst.setString(4, param);
        pst.setString(5, param);
        pst.setString(6, param);

        ResultSet rs = pst.executeQuery();

        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(0);

        while (rs.next()) {

            String def = rs.getString("deficiencia");
            if (def == null || def.trim().isEmpty()) {
                def = "Nenhuma";
            }

            modelo.addRow(new Object[]{
                rs.getInt("id_cadastro_usuario"),
                rs.getString("nome"),
             rs.getString("tipo_usuario"),   // <-- NOVO
                rs.getString("cpf"),
                rs.getString("data_nascimento"),
                rs.getString("telefone"),
                rs.getString("email"),
                def,
                rs.getString("situacao"),
                    
            });
        }

    } catch (Exception e) {
        System.out.println("Erro ao pesquisar cadastro: " + e);
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        possuiDeficiencia = new javax.swing.ButtonGroup();
        deficiencias = new javax.swing.ButtonGroup();
        situacao = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        painelGuias = new javax.swing.JTabbedPane();
        painelConsulta = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        pesquisaNome = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        editar_cadastro = new javax.swing.JButton();
        excluir_cadastro = new javax.swing.JButton();
        painelDadosPessoais = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        codigo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        telefone = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        rbsim = new javax.swing.JRadioButton();
        rbnao = new javax.swing.JRadioButton();
        rbauditivo = new javax.swing.JCheckBox();
        rbintelectual = new javax.swing.JCheckBox();
        rbvisual = new javax.swing.JCheckBox();
        rbmotora = new javax.swing.JCheckBox();
        rbneurologica = new javax.swing.JCheckBox();
        rbpisiquica = new javax.swing.JCheckBox();
        rboutros = new javax.swing.JCheckBox();
        rbcardiaca = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        senha = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        confirmar_senha = new javax.swing.JPasswordField();
        btSalvar = new javax.swing.JButton();
        data_nascimento = new com.toedter.calendar.JDateChooser();
        salvar_cadastro = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        ativo = new javax.swing.JRadioButton();
        Inativo = new javax.swing.JRadioButton();
        cpf = new javax.swing.JFormattedTextField();
        tipoUsuario = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tela Cadastro Usuario");

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("CADASTRO DE USUARIO");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        painelGuias.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jLabel16.setText("Nome:");

        pesquisaNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pesquisaNomeActionPerformed(evt);
            }
        });
        pesquisaNome.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pesquisaNomeKeyPressed(evt);
            }
        });

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Nome", "Usuario", "Cpf", "Data_nascimento", "Telefone", "Email", "Deficiência", "Situação"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabela);

        editar_cadastro.setText("Editar");
        editar_cadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editar_cadastroMouseClicked(evt);
            }
        });

        excluir_cadastro.setText("Excluir");
        excluir_cadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                excluir_cadastroMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout painelConsultaLayout = new javax.swing.GroupLayout(painelConsulta);
        painelConsulta.setLayout(painelConsultaLayout);
        painelConsultaLayout.setHorizontalGroup(
            painelConsultaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelConsultaLayout.createSequentialGroup()
                .addGroup(painelConsultaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelConsultaLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pesquisaNome, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelConsultaLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1053, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(131, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelConsultaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(editar_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(90, 90, 90)
                .addComponent(excluir_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(441, 441, 441))
        );
        painelConsultaLayout.setVerticalGroup(
            painelConsultaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelConsultaLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(painelConsultaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(pesquisaNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(painelConsultaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(excluir_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editar_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(133, Short.MAX_VALUE))
        );

        painelGuias.addTab("Pesquisa Usuario", painelConsulta);

        jLabel3.setText("Codigo:");

        jLabel4.setText("Nome Usuario:");

        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });

        jLabel5.setText("Cpf");

        try {
            telefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel9.setText("Data Nascimento");

        jLabel11.setText("Telefone");

        jLabel14.setText("Email");

        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });

        jLabel1.setText("Possui alguma Deficiencia:");

        possuiDeficiencia.add(rbsim);
        rbsim.setText("Sim");
        rbsim.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbsimMouseClicked(evt);
            }
        });

        possuiDeficiencia.add(rbnao);
        rbnao.setText("Não");
        rbnao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbnaoMouseClicked(evt);
            }
        });

        deficiencias.add(rbauditivo);
        rbauditivo.setText("Deficiencia Auditiva");
        rbauditivo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbauditivoMouseClicked(evt);
            }
        });

        deficiencias.add(rbintelectual);
        rbintelectual.setText("Deficiencia Intelectual");
        rbintelectual.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbintelectualMouseClicked(evt);
            }
        });

        deficiencias.add(rbvisual);
        rbvisual.setText("Deficiencia Visual");
        rbvisual.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbvisualMouseClicked(evt);
            }
        });
        rbvisual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbvisualActionPerformed(evt);
            }
        });

        deficiencias.add(rbmotora);
        rbmotora.setText("Deficiencia Motora");
        rbmotora.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbmotoraMouseClicked(evt);
            }
        });

        deficiencias.add(rbneurologica);
        rbneurologica.setText("Deficiencia Neurologica");
        rbneurologica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbneurologicaMouseClicked(evt);
            }
        });

        deficiencias.add(rbpisiquica);
        rbpisiquica.setText("Deficiencia Pisiquica");
        rbpisiquica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbpisiquicaMouseClicked(evt);
            }
        });

        deficiencias.add(rboutros);
        rboutros.setText("Outros");
        rboutros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rboutrosMouseClicked(evt);
            }
        });

        deficiencias.add(rbcardiaca);
        rbcardiaca.setText("Deficiencia Cardiaca");
        rbcardiaca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbcardiacaMouseClicked(evt);
            }
        });

        jLabel6.setText("Senha");

        jLabel7.setText("Confirmar Senha");

        btSalvar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btSalvar.setText("CADASTRAR USUARIO");
        btSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btSalvarMouseClicked(evt);
            }
        });

        salvar_cadastro.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        salvar_cadastro.setText("SALVAR");
        salvar_cadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salvar_cadastroMouseClicked(evt);
            }
        });

        jLabel8.setText("Situação:");

        situacao.add(ativo);
        ativo.setText("Ativo");

        situacao.add(Inativo);
        Inativo.setText("Inativo");

        tipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Escolha o Usuario", "Admin", "User", " " }));

        jLabel10.setText("Tipo de Usuario:");

        javax.swing.GroupLayout painelDadosPessoaisLayout = new javax.swing.GroupLayout(painelDadosPessoais);
        painelDadosPessoais.setLayout(painelDadosPessoaisLayout);
        painelDadosPessoaisLayout.setHorizontalGroup(
            painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbintelectual)
                            .addComponent(rboutros)
                            .addComponent(rbpisiquica, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rbneurologica))
                        .addGap(170, 170, 170))
                    .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(data_nascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tipoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(361, 361, 361)
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbcardiaca)
                            .addComponent(rbmotora)
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(34, 34, 34)
                                .addComponent(rbsim)
                                .addGap(45, 45, 45)
                                .addComponent(rbnao))
                            .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(rbvisual, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(rbauditivo)))
                        .addContainerGap(168, Short.MAX_VALUE))))
            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(btSalvar)
                        .addGap(81, 81, 81)
                        .addComponent(salvar_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(ativo)
                                .addGap(18, 18, 18)
                                .addComponent(Inativo))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(confirmar_senha, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        painelDadosPessoaisLayout.setVerticalGroup(
            painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(rbsim)
                    .addComponent(rbnao))
                .addGap(24, 24, 24)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbvisual)
                    .addComponent(rbintelectual))
                .addGap(18, 18, 18)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(painelDadosPessoaisLayout.createSequentialGroup()
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rbauditivo)
                            .addComponent(rbneurologica))
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, painelDadosPessoaisLayout.createSequentialGroup()
                        .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tipoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)))
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbmotora)
                    .addComponent(rbpisiquica)
                    .addComponent(jLabel5)
                    .addComponent(cpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rboutros)
                        .addComponent(rbcardiaca))
                    .addComponent(data_nascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(27, 27, 27)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11)
                    .addComponent(telefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addGap(18, 18, 18)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(senha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(confirmar_senha, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(ativo)
                    .addComponent(Inativo))
                .addGap(57, 57, 57)
                .addGroup(painelDadosPessoaisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salvar_cadastro, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 95, Short.MAX_VALUE))
        );

        painelGuias.addTab("Dados Pessoais", painelDadosPessoais);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(painelGuias)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(painelGuias, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(118, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeActionPerformed

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void tabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseClicked
    String data;
    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

    // === PEGANDO DADOS DAS COLUNAS ===
    this.codigo.setText(tabela.getValueAt(tabela.getSelectedRow(), 0).toString());
    this.nome.setText(tabela.getValueAt(tabela.getSelectedRow(), 1).toString());

 
    // caso seja JComboBox:
     this.tipoUsuario.setSelectedItem(tabela.getValueAt(tabela.getSelectedRow(), 2).toString());

    this.cpf.setText(tabela.getValueAt(tabela.getSelectedRow(), 3).toString());

    data = tabela.getValueAt(tabela.getSelectedRow(), 4).toString();
    this.telefone.setText(tabela.getValueAt(tabela.getSelectedRow(), 5).toString());
    this.email.setText(tabela.getValueAt(tabela.getSelectedRow(), 6).toString());

    // === DATA DE NASCIMENTO ===
    try {
        Date datanasceu = formato.parse(data);
        this.data_nascimento.setDate(datanasceu);
    } catch (Exception e) {
        System.getLogger(TelaCadastro2.class.getName())
              .log(System.Logger.Level.ERROR, (String) null, e);
    }

    // === DEFICIÊNCIA ===
    String def = tabela.getValueAt(tabela.getSelectedRow(), 7).toString();

    // === SITUAÇÃO (A ou I) ===
    String situacao = tabela.getValueAt(tabela.getSelectedRow(), 8).toString();
    if (situacao.equals("A")) {
        ativo.setSelected(true);
        Inativo.setSelected(false);
    } else {
        ativo.setSelected(false);
        Inativo.setSelected(true);
    }

    // === LIMPA SELEÇÃO DAS DEFICIÊNCIAS ===
    deficiencias.clearSelection();

    // NÃO TEM DEFICIÊNCIA
    if (def.trim().isEmpty()) {
        rbnao.setSelected(true);
        rbsim.setSelected(false);
    } else {
        rbsim.setSelected(true);
        rbnao.setSelected(false);
    }

    // MARCA CHECKBOX CONFORME O TEXTO
    if (def.contains("Visual")) rbvisual.setSelected(true);
    if (def.contains("Auditiva")) rbauditivo.setSelected(true);
    if (def.contains("Motora")) rbmotora.setSelected(true);
    if (def.contains("Cardíaca")) rbcardiaca.setSelected(true);
    if (def.contains("Intelectual")) rbintelectual.setSelected(true);
    if (def.contains("Neurológica")) rbneurologica.setSelected(true);
    if (def.contains("Psíquica")) rbpisiquica.setSelected(true);
    if (def.contains("Outros")) rboutros.setSelected(true);

    editar_cadastro.setEnabled(true);
    excluir_cadastro.setEnabled(true);
    }//GEN-LAST:event_tabelaMouseClicked

    private void rbvisualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbvisualActionPerformed
       
    }//GEN-LAST:event_rbvisualActionPerformed

    private void btSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btSalvarMouseClicked
 // Verifica campos obrigatórios e insere dados no banco
 //boolean camposValidos = true;
 
      Date dataSelecionada = data_nascimento.getDate();    
    
    if (dataSelecionada == null) {
        JOptionPane.showMessageDialog(null, "Por favor, preencha os campos em branco!", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Converter data para formato compatível com MySQL
    SimpleDateFormat formatoMysql = new SimpleDateFormat("yyyy-MM-dd");
    String dataFormatada = formatoMysql.format(dataSelecionada);

    // Validar senhas ANTES do insert
    String senhaText = new String(senha.getPassword()).trim(); // se for JPasswordField
    String confirmarSenhaText = new String(confirmar_senha.getPassword()).trim();
    
    
    
    if (!senhaText.equals(confirmarSenhaText)) {
        JOptionPane.showMessageDialog(null, "As senhas não coincidem!", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Validar campos obrigatórios
    if (nome.getText().trim().isEmpty() ||
        cpf.getText().trim().isEmpty() ||
        telefone.getText().trim().isEmpty() ||
        email.getText().trim().isEmpty()) {
        
        JOptionPane.showMessageDialog(null, "Preencha todos os campos!", "Erro", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Conexão com o banco
    

  try {
    Connection con = ConexaoMysql.conexaoBanco();
    con.setAutoCommit(false); // inicia transação

    // =====================================================================
    // 1) LOGIN
    // =====================================================================
   String sqlLogin = "INSERT INTO login (usuario, senha, tipo_usuario) VALUES (?, SHA2(?,512), ?)";

    PreparedStatement stmtLogin = con.prepareStatement(sqlLogin, PreparedStatement.RETURN_GENERATED_KEYS);

   stmtLogin.setString(1, nome.getText().trim());
stmtLogin.setString(2, senhaText);
stmtLogin.setString(3, tipoUsuario.getSelectedItem().toString());

    stmtLogin.executeUpdate();

    ResultSet rsLogin = stmtLogin.getGeneratedKeys();
    int idLogin = 0;

    if (rsLogin.next()) {
        idLogin = rsLogin.getInt(1);
    } else {
        throw new SQLException("Erro ao obter ID do login.");
    }

    // =====================================================================
    // 2) CADASTRO_USUARIO  (AQUI O CPF UNIQUE É VERIFICADO PELO BANCO)
    // =====================================================================
    String sqlCadastro =
        "INSERT INTO cadastro_usuario (nome, cpf, data_nascimento, telefone, email, id_login) "
        + "VALUES (?, ?, ?, ?, ?, ?)";

    PreparedStatement stmtCad = con.prepareStatement(sqlCadastro, PreparedStatement.RETURN_GENERATED_KEYS);
    stmtCad.setString(1, nome.getText().trim());
    stmtCad.setString(2, cpf.getText().trim());
    stmtCad.setString(3, dataFormatada);
    stmtCad.setString(4, telefone.getText().trim());
    stmtCad.setString(5, email.getText().trim());
    stmtCad.setInt(6, idLogin);
    stmtCad.executeUpdate();

    ResultSet rsCad = stmtCad.getGeneratedKeys();
    int idUsuario = 0;

    if (rsCad.next()) {
        idUsuario = rsCad.getInt(1);
    } else {
        throw new SQLException("Erro ao obter ID do usuário.");
    }

    // =====================================================================
    // 3) ACESSIBILIDADE
    // =====================================================================
    String sqlAcess =
        "INSERT INTO acessibilidade (d_visual, d_auditiva, d_motora, d_cardiaca, d_intelectual, "
      + "d_neurologica, d_psiquica, outros, id_cadastro_usuario) "
      + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    PreparedStatement stmtAcess = con.prepareStatement(sqlAcess);
    stmtAcess.setInt(1, rbvisual.isSelected() ? 1 : 0);
    stmtAcess.setInt(2, rbauditivo.isSelected() ? 1 : 0);
    stmtAcess.setInt(3, rbmotora.isSelected() ? 1 : 0);
    stmtAcess.setInt(4, rbcardiaca.isSelected() ? 1 : 0);
    stmtAcess.setInt(5, rbintelectual.isSelected() ? 1 : 0);
    stmtAcess.setInt(6, rbneurologica.isSelected() ? 1 : 0);
    stmtAcess.setInt(7, rbpisiquica.isSelected() ? 1 : 0);
    stmtAcess.setInt(8, rboutros.isSelected() ? 1 : 0);
    stmtAcess.setInt(9, idUsuario);
    stmtAcess.executeUpdate();

    // =====================================================================
    // 4) CONFIRMA TRANSAÇÃO
    // =====================================================================
    con.commit();

    // ABRE A TELA DE ENDEREÇO
    Endereco endereco = new Endereco(new javax.swing.JFrame(), true);
    endereco.setVisible(true);

    this.dispose();
    stmtCad.close();

} catch (SQLException ex) {

    // ===== CPF DUPLICADO (ERRO 1062 DO MYSQL) =====
    if (ex.getErrorCode() == 1062) {
        JOptionPane.showMessageDialog(null,
                "CPF já cadastrado! Não é permitido repetir.",
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );
        return;
    }

    JOptionPane.showMessageDialog(null,
            "Erro ao cadastrar: " + ex.getMessage(),
            "Erro",
            JOptionPane.ERROR_MESSAGE
    );

    ex.printStackTrace();

    try {
        Connection con = ConexaoMysql.conexaoBanco();
        con.rollback();
    } catch (Exception e2) {
        System.out.println("Erro ao fazer rollback: " + e2.getMessage());
    }
}

Limparcampo();

        
    }//GEN-LAST:event_btSalvarMouseClicked

    private void pesquisaNomeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pesquisaNomeKeyPressed
 /* try {
            Connection conn = ConexaoMysql.conexaoBanco();
            String sql = "SELECT \n" +
"    cu.id_cadastro_usuario,\n" +
"    cu.nome,\n" +
"    cu.cpf\n" +              
"    cu.data_nascimento,\n" +                     
"    cu.telefone,\n" +          
"    cu.email\n" +                       
"FROM endereco e\n" +
"INNER JOIN cadastro_usuario cu \n" +
"    ON cu.id_cadastro_usuario = e.id_cadastro_usuario\n" +
"WHERE cu.nome LIKE '%"+this.pesquisaNome.getText()+"%';";     
        PreparedStatement stmt = conn.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(0);
        while(rs.next()){
             Object[] dados = {
        rs.getInt("id_cadastro_usuario"),
        rs.getString("nome"),
        rs.getString("cpf"),
        rs.getString("data_nascimento"),  
        rs.getString("telefone"),
        rs.getString("email"),
                     
        
        
       
    };
    modelo.addRow(dados);
        }
        
        } catch (SQLException ex) {
            Logger.getLogger(TelaCadastro2.class.getName()).log(Level.SEVERE, null, ex);
        }    
        */
 pesquisarCadastro();
    }//GEN-LAST:event_pesquisaNomeKeyPressed

    private void rbnaoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbnaoMouseClicked
       rbvisual.setVisible(false);
       rbauditivo.setVisible(false);
       rbmotora.setVisible(false);
       rboutros.setVisible(false);
       rbcardiaca.setVisible(false);
       rbintelectual.setVisible(false);
       rbneurologica.setVisible(false);
       rbpisiquica.setVisible(false);
       
    }//GEN-LAST:event_rbnaoMouseClicked

    private void rbsimMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbsimMouseClicked
       rbvisual.setVisible(true);
       rbauditivo.setVisible(true);
       rbmotora.setVisible(true);
       rboutros.setVisible(true);
       rbcardiaca.setVisible(true);
       rbintelectual.setVisible(true);
       rbneurologica.setVisible(true);
       rbpisiquica.setVisible(true);
       
        
       
       
            
        
       
    }//GEN-LAST:event_rbsimMouseClicked

    private void rbvisualMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbvisualMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbvisualMouseClicked

    private void rbintelectualMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbintelectualMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbintelectualMouseClicked

    private void rbauditivoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbauditivoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbauditivoMouseClicked

    private void rbneurologicaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbneurologicaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbneurologicaMouseClicked

    private void rbmotoraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbmotoraMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbmotoraMouseClicked

    private void rbpisiquicaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbpisiquicaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbpisiquicaMouseClicked

    private void rbcardiacaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbcardiacaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rbcardiacaMouseClicked

    private void rboutrosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rboutrosMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_rboutrosMouseClicked

    private void salvar_cadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salvar_cadastroMouseClicked
     try {

        // ======== PEGAR A DATA ===========
        Date dataSelecionada = data_nascimento.getDate();
        String dataStr = null;

        if (dataSelecionada != null) {
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            dataStr = formato.format(dataSelecionada);
        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma data válida!");
            return;
        }

           String situacao = ativo.isSelected() ? "A" : "I";
        
        // ======== PEGAR ID ========
        int idUsuario = Integer.parseInt(codigo.getText());

        // ======== CONEXÃO ========
        Connection con = ConexaoMysql.conexaoBanco();


        // =====================================================================
        // 1️⃣ UPDATE CADASTRO_USUARIO
        // =====================================================================
        String sqlUsuario = 
            "UPDATE cadastro_usuario SET nome = ?, cpf = ?, data_nascimento = ?, "
          + "telefone = ?, email = ?, situacao = ? "
          + "WHERE id_cadastro_usuario = ?";

        PreparedStatement pstUsuario = con.prepareStatement(sqlUsuario);

        pstUsuario.setString(1, nome.getText());
        pstUsuario.setString(2, cpf.getText());
        pstUsuario.setString(3, dataStr);
        pstUsuario.setString(4, telefone.getText());
        pstUsuario.setString(5, email.getText());
        pstUsuario.setString(6, situacao); // <-- precisa vir do radioButton

        pstUsuario.setInt(7, idUsuario);

        pstUsuario.executeUpdate();
      


        // =====================================================================
        // 2️⃣ UPDATE ACESSIBILIDADE
        // =====================================================================
        String sqlAcess = 
            "UPDATE acessibilidade SET d_visual = ?, d_auditiva = ?, d_motora = ?, "
          + "d_cardiaca = ?, d_intelectual = ?, d_neurologica = ?, d_psiquica = ?, outros = ? "
          + "WHERE id_cadastro_usuario = ?";

        PreparedStatement pstAcess = con.prepareStatement(sqlAcess);

        pstAcess.setInt(1, rbvisual.isSelected() ? 1 : 0);
        pstAcess.setInt(2, rbauditivo.isSelected() ? 1 : 0);
        pstAcess.setInt(3, rbmotora.isSelected() ? 1 : 0);
        pstAcess.setInt(4, rbcardiaca.isSelected() ? 1 : 0);
        pstAcess.setInt(5, rbintelectual.isSelected() ? 1 : 0);
        pstAcess.setInt(6, rbneurologica.isSelected() ? 1 : 0);
        pstAcess.setInt(7, rbpisiquica.isSelected() ? 1 : 0);
        pstAcess.setInt(8, rboutros.isSelected() ? 1 : 0);

        pstAcess.setInt(9, idUsuario);

        pstAcess.executeUpdate();

 JOptionPane.showMessageDialog(null, "Dados pessoais atualizados! Agora edite o endereço.");

Endereco end = new Endereco(null, true);
end.carregarEnderecoParaEdicao(Integer.parseInt(codigo.getText()));
end.setVisible(true);
    dispose();
      Limparcampo();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao salvar: " + e.getMessage());
    }

    }//GEN-LAST:event_salvar_cadastroMouseClicked

    private void editar_cadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editar_cadastroMouseClicked
         // Verificar se alguma linha foi selecionada
   
         
         painelGuias.setSelectedIndex(1);

    // Habilita o botão salvar
    salvar_cadastro.setEnabled(true);

    // Desabilita o botão cadastrar para evitar confusão
    btSalvar.setEnabled(false);
    senha.setEnabled(false);
    confirmar_senha.setEnabled(false);
     cpf.setEnabled(false);
     tipoUsuario.setEnabled(false);
   

         
         /*int linha = tabela.getSelectedRow();
    if (linha == -1) {
        JOptionPane.showMessageDialog(null, "Selecione um cadastro na tabela!");
        return;
    }

    // --- PEGAR OS VALORES DA TABELA ---
    try {

        codigo.setText(tabela.getValueAt(linha, 0).toString());
        nome.setText(tabela.getValueAt(linha, 1).toString());
        cpf.setText(tabela.getValueAt(linha, 2).toString());

        // DATA
        String dataTabela = tabela.getValueAt(linha, 3).toString();
        try {
            SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
            Date dataConvertida = formato.parse(dataTabela);
            data_nascimento.setDate(dataConvertida);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erro ao converter data: " + ex.getMessage());
        }

        telefone.setText(tabela.getValueAt(linha, 4).toString());
        email.setText(tabela.getValueAt(linha, 5).toString());

        // --- PEGAR DEFICIÊNCIAS (coluna 6) ---
        String defValor = tabela.getValueAt(linha, 6).toString().toLowerCase();

        rbvisual.setSelected(defValor.contains("visual"));
        rbauditivo.setSelected(defValor.contains("auditiva"));
        rbmotora.setSelected(defValor.contains("motora"));
        rbcardiaca.setSelected(defValor.contains("cardíaca") || defValor.contains("cardiaca"));
        rbintelectual.setSelected(defValor.contains("intelectual"));
        rbneurologica.setSelected(defValor.contains("neurológica") || defValor.contains("neurologica"));
        rbpisiquica.setSelected(defValor.contains("psíquica") || defValor.contains("psiquica"));
        rboutros.setSelected(defValor.contains("outros"));

        // --- PEGAR SITUAÇÃO (COLUNA 7) ---
        String situacaoTabela = tabela.getValueAt(linha, 7).toString();

        if (situacaoTabela.equalsIgnoreCase("A")) {
            ativo.setSelected(true);
        } else {
            Inativo.setSelected(true);
        }

        // HABILITAR CAMPOS E BOTOES IGUAL EVENTOS
        salvar_cadastro.setEnabled(true);
        excluir_cadastro.setEnabled(true);
        nome.setEnabled(true);
        cpf.setEnabled(true);
        telefone.setEnabled(true);
        email.setEnabled(true);
        data_nascimento.setEnabled(true);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao carregar cadastro: " + e.getMessage());
    }
*/
    }//GEN-LAST:event_editar_cadastroMouseClicked

    private void excluir_cadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_excluir_cadastroMouseClicked
        int opcao = JOptionPane.showConfirmDialog(
            null,
            "Tem certeza que deseja excluir este cadastro?",
            "Confirmar exclusão",
            JOptionPane.YES_NO_OPTION
    );

    if (opcao != JOptionPane.YES_OPTION) {
        return;
    }

    try {
        int id = Integer.parseInt(codigo.getText());

        Connection con = ConexaoMysql.conexaoBanco();

        // 1️⃣ EXCLUIR ACESSIBILIDADE PRIMEIRO (FK)
        String sqlAcess = "DELETE FROM acessibilidade WHERE id_cadastro_usuario = ?";
        PreparedStatement pstA = con.prepareStatement(sqlAcess);
        pstA.setInt(1, id);
        pstA.executeUpdate();

        // 2️⃣ EXCLUIR O CADASTRO DO USUÁRIO
        String sqlUser = "DELETE FROM cadastro_usuario WHERE id_cadastro_usuario = ?";
        PreparedStatement pstU = con.prepareStatement(sqlUser);
        pstU.setInt(1, id);
        pstU.executeUpdate();

        JOptionPane.showMessageDialog(null, "Cadastro excluído com sucesso!");

        // 3️⃣ LIMPAR CAMPOS
        codigo.setText("");
        nome.setText("");
        cpf.setText("");
        email.setText("");
        telefone.setText("");
        data_nascimento.setDate(null);
        situacao.clearSelection();

        // desmarca checkboxes
        rbvisual.setSelected(false);
        rbauditivo.setSelected(false);
        rbmotora.setSelected(false);
        rbcardiaca.setSelected(false);
        rbintelectual.setSelected(false);
        rbneurologica.setSelected(false);
        rbpisiquica.setSelected(false);
        rboutros.setSelected(false);

        // ATUALIZA TABELA
        atualizarValores();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir: " + e.getMessage());
    }
    }//GEN-LAST:event_excluir_cadastroMouseClicked

    private void pesquisaNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pesquisaNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pesquisaNomeActionPerformed
      public static void main(String args[]){
         
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            TelaCadastro2 dialog = new TelaCadastro2(new javax.swing.JFrame(), true);
            dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {
                    System.exit(0);
                }
            });
            dialog.setVisible(true);
        }
    });
}
            
       

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Inativo;
    private javax.swing.JRadioButton ativo;
    private javax.swing.JButton btSalvar;
    private javax.swing.JTextField codigo;
    private javax.swing.JPasswordField confirmar_senha;
    private javax.swing.JFormattedTextField cpf;
    private com.toedter.calendar.JDateChooser data_nascimento;
    private javax.swing.ButtonGroup deficiencias;
    private javax.swing.JButton editar_cadastro;
    private javax.swing.JTextField email;
    private javax.swing.JButton excluir_cadastro;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField nome;
    private javax.swing.JPanel painelConsulta;
    private javax.swing.JPanel painelDadosPessoais;
    private javax.swing.JTabbedPane painelGuias;
    private javax.swing.JTextField pesquisaNome;
    private javax.swing.ButtonGroup possuiDeficiencia;
    private javax.swing.JCheckBox rbauditivo;
    private javax.swing.JCheckBox rbcardiaca;
    private javax.swing.JCheckBox rbintelectual;
    private javax.swing.JCheckBox rbmotora;
    private javax.swing.JRadioButton rbnao;
    private javax.swing.JCheckBox rbneurologica;
    private javax.swing.JCheckBox rboutros;
    private javax.swing.JCheckBox rbpisiquica;
    private javax.swing.JRadioButton rbsim;
    private javax.swing.JCheckBox rbvisual;
    private javax.swing.JButton salvar_cadastro;
    private javax.swing.JPasswordField senha;
    private javax.swing.ButtonGroup situacao;
    private javax.swing.JTable tabela;
    private javax.swing.JFormattedTextField telefone;
    private javax.swing.JComboBox<String> tipoUsuario;
    // End of variables declaration//GEN-END:variables

   
   
}
