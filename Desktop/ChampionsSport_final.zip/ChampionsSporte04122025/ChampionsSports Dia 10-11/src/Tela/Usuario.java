/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Tela;
import Conexao.ConexaoMysql;
import com.sun.jdi.connect.spi.Connection;
import java.beans.PropertyVetoException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Layanne
 */
public class Usuario extends javax.swing.JInternalFrame {

    private Object ConexaoMysql;

    /**
     * Creates new form teste
     * @throws java.beans.PropertyVetoException
     */
    public Usuario() {
        try {
            initComponents();
            setMaximum(true);
            
            imagemFundo1.setImg(new ImageIcon(getClass().getResource("Imagemfundo.png")));
        } catch (PropertyVetoException ex) {
            Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         
         
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        imagemFundo1 = new imagemfundo.ImagemFundo();
        jLabel1 = new javax.swing.JLabel();
        rbEditar_Cadastro = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        rbSair_Uario = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();

        setBackground(new java.awt.Color(174, 178, 212));
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagem/login2 (1).png"))); // NOI18N

        rbEditar_Cadastro.setBackground(new java.awt.Color(51, 23, 108));
        rbEditar_Cadastro.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        rbEditar_Cadastro.setForeground(new java.awt.Color(255, 255, 255));
        rbEditar_Cadastro.setText("EDITAR CADASTRO");
        rbEditar_Cadastro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbEditar_CadastroMouseClicked(evt);
            }
        });
        rbEditar_Cadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbEditar_CadastroActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 23, 108));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText(" FAVORITOS");

        jButton3.setBackground(new java.awt.Color(51, 23, 108));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText(" CONTATO");

        rbSair_Uario.setBackground(new java.awt.Color(51, 23, 108));
        rbSair_Uario.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        rbSair_Uario.setForeground(new java.awt.Color(255, 255, 255));
        rbSair_Uario.setText("SAIR");
        rbSair_Uario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rbSair_UarioMouseClicked(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(51, 23, 108));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("USUARIO");

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton5.setText("ALTERAR FOTO");

        javax.swing.GroupLayout imagemFundo1Layout = new javax.swing.GroupLayout(imagemFundo1);
        imagemFundo1.setLayout(imagemFundo1Layout);
        imagemFundo1Layout.setHorizontalGroup(
            imagemFundo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(imagemFundo1Layout.createSequentialGroup()
                .addGap(313, 313, 313)
                .addGroup(imagemFundo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(imagemFundo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(imagemFundo1Layout.createSequentialGroup()
                            .addGap(66, 66, 66)
                            .addComponent(rbSair_Uario, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rbEditar_Cadastro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(imagemFundo1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(imagemFundo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(419, Short.MAX_VALUE))
        );
        imagemFundo1Layout.setVerticalGroup(
            imagemFundo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(imagemFundo1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(32, 32, 32)
                .addComponent(jButton5)
                .addGap(18, 18, 18)
                .addComponent(rbEditar_Cadastro)
                .addGap(18, 18, 18)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addGap(31, 31, 31)
                .addComponent(rbSair_Uario)
                .addContainerGap(117, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(imagemFundo1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(imagemFundo1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbSair_UarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbSair_UarioMouseClicked
        dispose();
    }//GEN-LAST:event_rbSair_UarioMouseClicked

    private void rbEditar_CadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbEditar_CadastroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbEditar_CadastroActionPerformed

    private void rbEditar_CadastroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rbEditar_CadastroMouseClicked

        TelaCadastro2 editarCadastro = new TelaCadastro2(new javax.swing.JFrame(), true);
        editarCadastro.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_rbEditar_CadastroMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private imagemfundo.ImagemFundo imagemFundo1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton rbEditar_Cadastro;
    private javax.swing.JButton rbSair_Uario;
    // End of variables declaration//GEN-END:variables
}
