package Conexao;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Layanne55896236
 */
public class ConexaoMysql {

    // ✅ Corrigido: novo driver do MySQL
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    // ✅ URL corrigida: incluiu timezone e desligou SSL para evitar warnings
    private static final String URL = "jdbc:mysql://localhost:3307/champions_sport?useSSL=false&serverTimezone=UTC";

    private static final String USER = "root";
    private static final String PASS = "1234";

    public static Connection conexaoBanco() throws SQLException {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USER, PASS);

        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Erro: Driver do MySQL não encontrado!", ex);

        } catch (SQLException ex) {
            throw new SQLException("Erro ao conectar ao banco de dados!", ex);
        }
    }
}

  
 




        
      
      